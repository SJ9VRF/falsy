# Falsify Before You Reward — paper package

This package contains:
- `main.tex`: complete redesigned manuscript.
- `refs.bib`: bibliography.
- `paper.pdf`: compiled manuscript.
- Figures copied from the executed controlled experimental suite.
- `paper_main_table.csv`: main result table.
- `FULL_RESULTS_REPORT.md`: detailed executed-results report.

Scope:
The paper intentionally makes its core empirical claim on controlled executable verification environments. It does not claim that Qwen/Llama, MATH-500, GSM8K, HumanEval, LoRA, or GRPO experiments were run.
