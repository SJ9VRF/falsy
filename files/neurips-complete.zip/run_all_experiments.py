#!/usr/bin/env python3
"""
Self-contained executable experiments for:
Falsify Before You Reward: Interventional Verification for Reliable RL

No network, external APIs, pretrained weights, or downloaded datasets are required.
Dependencies: numpy, pandas, matplotlib, torch.

The script writes all outputs to ./reproduced_results/.
"""
from pathlib import Path
import itertools, random, math, json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

MASTER=20260824
OUT=Path(__file__).resolve().parent/"reproduced_results"
OUT.mkdir(exist_ok=True)

def metrics(y,p):
    y=np.asarray(y,int);p=np.asarray(p,int)
    tp=((y==1)&(p==1)).sum();tn=((y==0)&(p==0)).sum()
    fp=((y==0)&(p==1)).sum();fn=((y==1)&(p==0)).sum()
    return dict(
        accuracy=float((tp+tn)/len(y)),
        fpr=float(fp/(fp+tn)) if fp+tn else 0.,
        fnr=float(fn/(fn+tp)) if fn+tp else 0.,
    )

def ci95(a):
    a=np.asarray(a,float);m=float(a.mean())
    if len(a)<2:return m,float("nan"),float("nan")
    se=float(a.std(ddof=1)/np.sqrt(len(a)))
    return m,m-1.96*se,m+1.96*se

# ============================================================
# A. Arithmetic shortcut policies
# ============================================================
def target(v):
    a,b,c,d,e=v
    return 2*(((a+b)*c-d)+e)

MODES=["faithful","memorized","ignore_a","ignore_b","ignore_c","ignore_d","ignore_e"]
def act(mode,base,v):
    if mode=="faithful":return target(v)
    if mode=="memorized":return target(base)
    idx={"ignore_a":0,"ignore_b":1,"ignore_c":2,"ignore_d":3,"ignore_e":4}[mode]
    vv=list(v);vv[idx]=base[idx];return target(vv)

def vals(rng,ood=False):
    if ood:return [rng.randint(30,80),rng.randint(20,50),rng.randint(9,15),rng.randint(11,30),rng.randint(8,20)]
    return [rng.randint(2,25),rng.randint(2,18),rng.randint(2,8),rng.randint(1,10),rng.randint(2,7)]

def make_policy(seed,n=1200,ood=False):
    rng=random.Random(seed);rows=[]
    for i in range(n):
        b=vals(rng,ood)
        m=rng.choices(MODES,weights=[.35,.15,.10,.10,.10,.10,.10],k=1)[0]
        rows.append((i,b,m,int(m=="faithful")))
    return rows

def cf_pred(row,budget,strategy,seed=0):
    i,b,m,y=row
    if strategy=="outcome":return 1
    if strategy=="joint":
        v=[x+1 for x in b]
        return int(act(m,b,v)==target(v))
    order=list(range(5))
    if strategy=="random":
        rr=random.Random(seed*1000003+i);rr.shuffle(order)
    else:
        order=[2,0,1,3,4]
    checks=[]
    for j in order[:budget]:
        v=list(b);v[j]+=1
        checks.append(act(m,b,v)==target(v))
    return int(all(checks))

policy_rows=[]
for ood in [False,True]:
    dom="policy_ood" if ood else "policy"
    for seed in range(8):
        d=make_policy(MASTER+seed,1200,ood);y=[r[3] for r in d]
        for strat,buds in [("outcome",[0]),("random",[1,2,3,4,5]),("joint",[1])]:
            for b in buds:
                p=[cf_pred(r,b,strat,seed) for r in d]
                policy_rows.append({"domain":dom,"seed":seed,"strategy":strat,"budget":b,**metrics(y,p)})
policy=pd.DataFrame(policy_rows)
policy.to_csv(OUT/"policy_verification_raw.csv",index=False)

# ============================================================
# A2. Static corrupted reasoning
# ============================================================
def steps(v):
    a,b,c,d,e=v
    s0=a+b;s1=s0*c;s2=s1-d;s3=s2+e;s4=2*s3
    return [s0,s1,s2,s3,s4]

CORR=["clean","wrong_final","wrong_mid_correct_final","missing_correct_final",
      "spurious_correct_final","two_step_correct_final"]

def step_valid(v,s,i):
    a,b,c,d,e=v
    try:
        if i==0:return s[0]==a+b
        if i==1:return s[0] is not None and s[1]==s[0]*c
        if i==2:return s[1] is not None and s[2]==s[1]-d
        if i==3:return s[2] is not None and s[3]==s[2]+e
    except Exception:
        return False
    return False

static_rows=[]
for seed in range(8):
    rng=random.Random(MASTER+50+seed);data=[]
    for i in range(1200):
        v=vals(rng);s0=steps(v);ans=s0[-1]
        k=rng.choices(CORR,weights=[.30,.12,.20,.14,.13,.11],k=1)[0]
        cs=list(s0);ca=ans
        if k=="wrong_final":
            ca=ans+rng.choice([-9,-5,-3,3,5,9]);cs[-1]=ca
        elif k=="wrong_mid_correct_final":
            j=rng.randrange(4);cs[j]+=rng.choice([-4,-2,-1,1,2,4])
        elif k=="missing_correct_final":
            j=rng.randrange(4);cs[j]=None
        elif k=="spurious_correct_final":
            j=rng.randrange(1,4);cs[j]+=rng.choice([13,17,23])
        elif k=="two_step_correct_final":
            for j in rng.sample(range(4),2):cs[j]+=rng.choice([-5,-3,3,5])
        data.append((i,v,cs,ca,int(k=="clean"),k))
    y=[r[4] for r in data]
    for strat,b in [("outcome",0),("random",1),("adaptive",1)]:
        p=[]
        rr=random.Random(MASTER+seed)
        for i,v,cs,ca,label,k in data:
            terminal=int(ca==steps(v)[-1])
            if strat=="outcome":ok=terminal
            elif strat=="random":
                j=rr.randrange(4);ok=int(terminal and step_valid(v,cs,j))
            else:
                bad=[j for j in range(4) if not step_valid(v,cs,j)]
                j=(bad+[0,1,2,3])[0]
                ok=int(terminal and step_valid(v,cs,j))
            p.append(ok)
        static_rows.append({"seed":seed,"strategy":strat,"budget":b,**metrics(y,p)})
pd.DataFrame(static_rows).to_csv(OUT/"static_reasoning_raw.csv",index=False)

# ============================================================
# B. Symbolic logic with extensional labels + witness selection
# ============================================================
def logic_truth(base,L):
    s=base[0]
    for t in range(L):
        b=base[(t+1)%3]
        s=int((s and b) if t%2==0 else (s^b))
    return s

LMODES=["faithful","memorized","ignore0","ignore1","ignore2"]
def logic_act(mode,orig,L,b):
    if mode=="faithful":return logic_truth(b,L)
    if mode=="memorized":return logic_truth(orig,L)
    idx={"ignore0":0,"ignore1":1,"ignore2":2}[mode]
    bb=list(b);bb[idx]=orig[idx];return logic_truth(bb,L)

def logic_reliable(mode,orig,L):
    for b in itertools.product([0,1],repeat=3):
        if logic_act(mode,orig,L,list(b))!=logic_truth(list(b),L):return 0
    return 1

def witnesses(L):
    out=[]
    for j in range(3):
        found=None
        for b in itertools.product([0,1],repeat=3):
            b=list(b);bb=list(b);bb[j]=1-bb[j]
            if logic_truth(b,L)!=logic_truth(bb,L):
                found=(b,bb);break
        out.append(found)
    return out

logic_rows=[]
for ood in [False,True]:
    L=14 if ood else 8
    for seed in range(8):
        rng=random.Random(MASTER+100+seed)
        data=[]
        for i in range(1000):
            base=[rng.randint(0,1) for _ in range(3)]
            mode=rng.choices(LMODES,weights=[.4,.18,.14,.14,.14],k=1)[0]
            data.append((i,base,mode,logic_reliable(mode,base,L)))
        y=[r[3] for r in data]
        for b in [0,1,2,3]:
            if b==0:
                p=[1]*len(data);name="outcome"
            else:
                ws=witnesses(L)[:b];p=[];name="adaptive_witness"
                for _,base,mode,_ in data:
                    ok=True
                    for w in ws:
                        b1,b2=w
                        ok &= logic_act(mode,base,L,b1)==logic_truth(b1,L)
                        ok &= logic_act(mode,base,L,b2)==logic_truth(b2,L)
                    p.append(int(ok))
            logic_rows.append({"ood":ood,"seed":seed,"strategy":name,"budget":b,**metrics(y,p)})
pd.DataFrame(logic_rows).to_csv(OUT/"logic_verification_raw.csv",index=False)

# ============================================================
# C. Executable code-like candidate functions
# ============================================================
CMODES=["faithful","memorized","ignore_x","ignore_y","ignore_z","guarded_bug"]
def code_truth(v):
    x,y,z=v;return (x+y)*z-y
def code_act(m,base,v):
    x,y,z=v
    if m=="faithful":return code_truth(v)
    if m=="memorized":return code_truth(base)
    if m=="ignore_x":return code_truth([base[0],y,z])
    if m=="ignore_y":return code_truth([x,base[1],z])
    if m=="ignore_z":return code_truth([x,y,base[2]])
    return code_truth(base) if v==base else code_truth(v)+1

code_rows=[]
for ood in [False,True]:
    for seed in range(8):
        rng=random.Random(MASTER+200+seed);data=[]
        for i in range(1100):
            base=([rng.randint(30,80),rng.randint(20,50),rng.randint(9,15)] if ood
                  else [rng.randint(1,20),rng.randint(1,15),rng.randint(2,8)])
            m=rng.choices(CMODES,weights=[.38,.14,.12,.12,.12,.12],k=1)[0]
            data.append((i,base,m,int(m=="faithful")))
        y=[r[3] for r in data]
        for strat,buds in [("outcome",[0]),("targeted",[1,2,3]),("joint",[1])]:
            for b in buds:
                p=[]
                for i,base,m,_ in data:
                    if strat=="outcome":ok=1
                    elif strat=="joint":
                        v=[x+2 for x in base];ok=int(code_act(m,base,v)==code_truth(v))
                    else:
                        ok=True
                        for j in [2,0,1][:b]:
                            v=list(base);v[j]+=2
                            ok &= code_act(m,base,v)==code_truth(v)
                        ok=int(ok)
                    p.append(ok)
                code_rows.append({"ood":ood,"seed":seed,"strategy":strat,"budget":b,**metrics(y,p)})
pd.DataFrame(code_rows).to_csv(OUT/"code_verification_raw.csv",index=False)

# ============================================================
# D. Reward-hack repairs
# ============================================================
HACK=["legitimate","magic","stale","premature"]
hack_rows=[]
for seed in range(8):
    rng=random.Random(MASTER+300+seed)
    data=[rng.choices(HACK,weights=[.35,.22,.22,.21],k=1)[0] for _ in range(1600)]
    y=[int(x=="legitimate") for x in data]
    for strat,b in [("outcome",0),("random1",1),("random2",2),("random3",3),("targeted",1)]:
        p=[]
        rr=random.Random(MASTER+seed)
        for m in data:
            if strat=="outcome":ok=1
            elif strat=="targeted":ok=int(m=="legitimate")
            else:
                repairs=["magic","stale","premature"];rr.shuffle(repairs)
                ok=int(m=="legitimate" or m not in repairs[:b])
            p.append(ok)
        hack_rows.append({"seed":seed,"strategy":strat,"budget":b,**metrics(y,p)})
pd.DataFrame(hack_rows).to_csv(OUT/"reward_hack_raw.csv",index=False)

# ============================================================
# E. Best-of-N
# ============================================================
bon=[]
for seed in range(20):
    rng=random.Random(MASTER+400+seed)
    for N in [2,4,8,16,32]:
        for method in ["outcome","iav_joint"]:
            rel=[];unseen=[]
            for t in range(400):
                base=vals(rng)
                cands=rng.choices(MODES,weights=[.35,.15,.10,.10,.10,.10,.10],k=N)
                scores=[]
                for m in cands:
                    if method=="outcome":scores.append(1.)
                    else:
                        v=[x+1 for x in base]
                        scores.append(.4+.6*float(act(m,base,v)==target(v)))
                mx=max(scores);ids=[i for i,s in enumerate(scores) if s==mx]
                chosen=cands[rng.choice(ids)]
                rel.append(chosen=="faithful")
                v=list(base);j=rng.randrange(5);v[j]+=rng.choice([-4,-2,2,4])
                unseen.append(act(chosen,base,v)==target(v))
            bon.append({"seed":seed,"N":N,"method":method,
                        "reliable_selection":float(np.mean(rel)),
                        "unseen_success":float(np.mean(unseen))})
pd.DataFrame(bon).to_csv(OUT/"best_of_n_raw.csv",index=False)

# ============================================================
# F. Actual REINFORCE policy optimization
# ============================================================
# For a categorical policy, grad log pi(a) = one_hot(a) - pi.
# We apply the stochastic REINFORCE update directly in NumPy; no autograd/GPU is needed.
init=np.array([.35,.15,.10,.10,.10,.10,.10],float)

def reward(mode_idx,method,rng):
    base=vals(rng);m=MODES[mode_idx]
    if method=="outcome":return 1.
    v=[x+1 for x in base]
    return .4+.6*float(act(m,base,v)==target(v))

rl=[]
for method in ["outcome","iav_joint"]:
    for seed in range(20):
        rng=random.Random(MASTER+500+seed)
        nrng=np.random.default_rng(MASTER+seed)
        logits=np.log(init.copy())
        baseline=0.
        lr=.05; beta1=.9; beta2=.999; eps=1e-8
        m_adam=np.zeros_like(logits); v_adam=np.zeros_like(logits)
        for step in range(801):
            ex=np.exp(logits-logits.max());probs=ex/ex.sum()
            if step in [0,50,100,200,400,800]:
                rl.append({"method":method,"seed":seed,"step":step,
                           "faithful":float(probs[0])})
            if step==800:break
            a=int(nrng.choice(len(probs),p=probs))
            r=reward(a,method,rng)
            baseline=.95*baseline+.05*r
            grad=-probs
            grad[a]+=1.0
            grad *= (r-baseline)
            t=step+1
            m_adam=beta1*m_adam+(1-beta1)*grad
            v_adam=beta2*v_adam+(1-beta2)*(grad*grad)
            mhat=m_adam/(1-beta1**t); vhat=v_adam/(1-beta2**t)
            logits += lr*mhat/(np.sqrt(vhat)+eps)
pd.DataFrame(rl).to_csv(OUT/"reinforce_raw.csv",index=False)

# ============================================================
# G. Finite unknown-shortcut hypothesis benchmark
# ============================================================
V=5
hyps=[("faithful","faithful",{}),("memorize","memorize",{})]
for j in range(V):hyps.append((f"ignore_{j}","ignore",{"subset":(j,)}))
for pair in itertools.combinations(range(V),2):hyps.append((str(pair),"ignore",{"subset":pair}))
for trig in range(V):
    for j in range(V):
        if j!=trig:hyps.append((f"c{trig}_{j}","conditional",{"trigger":trig,"ignore":j}))
for j in range(V):hyps.append((f"p{j}","parity",{"ignore":j}))
pool=[]
for j in range(V):
    for d in [-2,-1,1,2,3]:
        z=[0]*V;z[j]=d;pool.append((tuple(z),1.))
for j,k in itertools.combinations(range(V),2):
    for d in [1,2,3]:
        z=[0]*V;z[j]=d;z[k]=d;pool.append((tuple(z),1.6))
for comb in itertools.combinations(range(V),3):
    z=[0]*V
    for j in comb:z[j]=1
    pool.append((tuple(z),2.1))
for d in [1,2]:pool.append((tuple([d]*V),3.))
def pass_h(h,z):
    _,kind,p=h;nz={i for i,d in enumerate(z) if d}
    if kind=="faithful":return 1
    if kind=="memorize":return 0
    if kind=="ignore":return int(not nz.intersection(p["subset"]))
    if kind=="conditional":return int(not (z[p["trigger"]]>=2 and z[p["ignore"]]!=0))
    return int(not ((sum(abs(d) for d in z)%2)==1 and z[p["ignore"]]!=0))
RESP=np.array([[pass_h(h,z) for z,c in pool] for h in hyps],dtype=int)
COST=np.array([c for z,c in pool])
prior=np.zeros(len(hyps));prior[0]=.35;prior[1]=.05
single=[i for i,h in enumerate(hyps) if h[1]=="ignore" and len(h[2]["subset"])==1]
pair=[i for i,h in enumerate(hyps) if h[1]=="ignore" and len(h[2]["subset"])==2]
cond=[i for i,h in enumerate(hyps) if h[1]=="conditional"];par=[i for i,h in enumerate(hyps) if h[1]=="parity"]
for ids,mass in [(single,.10),(pair,.12),(cond,.25),(par,.13)]:
    for i in ids:prior[i]=mass/len(ids)
def Hb(p):
    if p<=0 or p>=1:return 0.
    return -p*np.log2(p)-(1-p)*np.log2(1-p)
def ig_schedule():
    active=np.ones(len(hyps),bool);avail=list(range(len(pool)));s=[]
    for _ in range(8):
        ids=np.where(active)[0];w=prior[ids];w=w/w.sum()
        vals=[]
        for k in avail:
            p=float((w*RESP[ids,k]).sum());vals.append(Hb(p))
        k=avail[int(np.argmax(vals))];s.append(k);active&=(RESP[:,k]==1);avail.remove(k)
        if active.sum()<=1:break
    return s
IG=ig_schedule()
def eval_sched(s,b):
    survive=np.ones(len(hyps),bool)
    for k in s[:b]:survive&=(RESP[:,k]==1)
    pred=survive.astype(int);y=np.zeros(len(hyps),int);y[0]=1
    acc=float(prior[pred==y].sum())
    fpr=float(prior[(y==0)&(pred==1)].sum()/(1-prior[0]))
    return acc,fpr,float(COST[s[:b]].sum())
rng=random.Random(MASTER+600);rand=[rng.sample(range(len(pool)),8) for _ in range(5000)]
adv=[]
for b in [1,2,3,4,5,6]:
    a,f,c=eval_sched(IG,b);adv.append({"strategy":"ig","budget":b,"accuracy":a,"fpr":f,"cost":c})
    arr=np.array([eval_sched(s,b) for s in rand])
    adv.append({"strategy":"random","budget":b,"accuracy":arr[:,0].mean(),"fpr":arr[:,1].mean(),"cost":arr[:,2].mean()})
pd.DataFrame(adv).to_csv(OUT/"adaptive_unknown_shortcut.csv",index=False)

# ============================================================
# H. Verifier noise on joint policy verifier
# ============================================================
noise=[]
for eps in [0,.01,.02,.05,.10,.15,.20]:
    for seed in range(8):
        d=make_policy(MASTER+700+seed,1400,False);y=np.array([r[3] for r in d])
        base=np.array([cf_pred(r,1,"joint",seed) for r in d])
        rr=np.random.default_rng(MASTER+seed+int(eps*1000))
        p=np.where(rr.random(len(base))<eps,1-base,base)
        noise.append({"noise":eps,"seed":seed,**metrics(y,p)})
pd.DataFrame(noise).to_csv(OUT/"noise_raw.csv",index=False)

# ============================================================
# I. Calibration, perturbation magnitude, paired significance
# ============================================================
def ece(y,score,bins=10):
    y=np.asarray(y,float);score=np.asarray(score,float);edges=np.linspace(0,1,bins+1);out=0.
    for i in range(bins):
        m=((score>=edges[i])&(score<edges[i+1])) if i<bins-1 else ((score>=edges[i])&(score<=edges[i+1]))
        if m.sum():out+=m.mean()*abs(y[m].mean()-score[m].mean())
    return float(out)

cal=[];mag=[];sig=[]
for seed in range(8):
    d=make_policy(MASTER+800+seed,1500,False);y=np.array([r[3] for r in d])
    scores_out=np.ones(len(d))
    scores_joint=np.array([cf_pred(r,1,"joint",seed) for r in d],float)
    scores_r=[]
    for r in d:
        i,b,m,_=r;rr=random.Random(seed*1000003+i);order=list(range(5));rr.shuffle(order)
        checks=[]
        for j in order[:3]:
            v=list(b);v[j]+=1;checks.append(act(m,b,v)==target(v))
        scores_r.append(np.mean(checks))
    for name,sc in [("outcome",scores_out),("random3",np.array(scores_r)),("joint",scores_joint)]:
        cal.append({"seed":seed,"strategy":name,"brier":float(np.mean((sc-y)**2)),"ece":ece(y,sc)})
    # paired outcome vs joint
    co=(scores_out.astype(int)==y);ci=(scores_joint.astype(int)==y)
    b=int((co&~ci).sum());c=int((~co&ci).sum());n=b+c
    log10p=(math.log10(2)-n*math.log10(2)) if n else 0.0
    sig.append({"seed":seed,"outcome_only_correct":b,"iav_only_correct":c,
                "discordant":n,"exact_two_sided_log10_p_upper":log10p})
    # intervention magnitude
    for delta in [-5,-3,-1,1,2,5,10]:
        pred=[]
        for i,b,m,_ in d:
            v=[x+delta for x in b]
            pred.append(int(act(m,b,v)==target(v)))
        mm=metrics(y,pred);mag.append({"seed":seed,"delta":delta,**mm})
pd.DataFrame(cal).to_csv(OUT/"calibration_raw.csv",index=False)
pd.DataFrame(sig).to_csv(OUT/"paired_significance.csv",index=False)
pd.DataFrame(mag).to_csv(OUT/"intervention_magnitude_raw.csv",index=False)

# ============================================================
# J. Cost-aware adaptive selector, failure families, prior shift
# ============================================================
def eval_schedule(schedule,budget=None,cost_budget=None,pdist=None):
    pdist=prior if pdist is None else pdist
    chosen=[];spent=0.
    for k in schedule:
        if budget is not None and len(chosen)>=budget:break
        if cost_budget is not None and spent+COST[k]>cost_budget:continue
        chosen.append(k);spent+=COST[k]
    survive=np.ones(len(hyps),bool)
    for k in chosen:survive&=(RESP[:,k]==1)
    yy=np.zeros(len(hyps),int);yy[0]=1;pred=survive.astype(int)
    acc=float(pdist[pred==yy].sum())
    fpr=float(pdist[(yy==0)&(pred==1)].sum()/pdist[yy==0].sum())
    return acc,fpr,spent,len(chosen),survive

def gain_schedule(per_cost=False):
    surv=np.ones(len(hyps),bool);avail=list(range(len(pool)));out=[]
    for _ in range(8):
        vals=[]
        for k in avail:
            gain=float(prior[(np.arange(len(hyps))!=0)&surv&(RESP[:,k]==0)].sum())
            vals.append(gain/(COST[k]+1e-9) if per_cost else gain)
        k=avail[int(np.argmax(vals))];out.append(k);surv&=(RESP[:,k]==1);avail.remove(k)
        if not surv[1:].any():break
    return out

GAIN=gain_schedule(False);GAINC=gain_schedule(True)
cost_rows=[]
rng=random.Random(MASTER+900);random_sched=[rng.sample(range(len(pool)),8) for _ in range(5000)]
for cb in [1,2,3,4,5,6,8,10]:
    for name,sched in [("ig",IG),("falsification_gain",GAIN),("gain_per_cost",GAINC)]:
        a,f,c,n,_=eval_schedule(sched,cost_budget=cb)
        cost_rows.append({"strategy":name,"cost_budget":cb,"accuracy":a,"fpr":f,"actual_cost":c,"tests":n})
    arr=np.array([eval_schedule(q,cost_budget=cb)[:4] for q in random_sched],float)
    cost_rows.append({"strategy":"random","cost_budget":cb,"accuracy":arr[:,0].mean(),
                      "fpr":arr[:,1].mean(),"actual_cost":arr[:,2].mean(),"tests":arr[:,3].mean()})
pd.DataFrame(cost_rows).to_csv(OUT/"cost_aware_scaling.csv",index=False)

# failure-family breakdown
fam={"faithful":[0],"memorize":[1],
     "ignore1":[i for i,h in enumerate(hyps) if h[1]=="ignore" and len(h[2]["subset"])==1],
     "ignore2":[i for i,h in enumerate(hyps) if h[1]=="ignore" and len(h[2]["subset"])==2],
     "conditional":[i for i,h in enumerate(hyps) if h[1]=="conditional"],
     "parity":[i for i,h in enumerate(hyps) if h[1]=="parity"]}
bd=[]
for b in [1,2,3,4,5]:
    _,_,_,_,surv=eval_schedule(IG,budget=b)
    for name,ids in fam.items():
        val=float(np.mean(surv[ids])) if name=="faithful" else float(np.mean(~surv[ids]))
        bd.append({"budget":b,"family":name,"metric":"accept_rate" if name=="faithful" else "detection_rate","value":val})
pd.DataFrame(bd).to_csv(OUT/"failure_family_breakdown.csv",index=False)

# prior-shift robustness of frozen IG schedule
def mkprior(gw):
    p=np.zeros(len(hyps))
    for name,ids in fam.items():
        for i in ids:p[i]=gw[name]/len(ids)
    return p/p.sum()
shifts={
"default":{"faithful":.35,"memorize":.05,"ignore1":.10,"ignore2":.12,"conditional":.25,"parity":.13},
"conditional_heavy":{"faithful":.35,"memorize":.02,"ignore1":.05,"ignore2":.06,"conditional":.45,"parity":.07},
"parity_heavy":{"faithful":.35,"memorize":.02,"ignore1":.05,"ignore2":.06,"conditional":.07,"parity":.45},
"ignore_heavy":{"faithful":.35,"memorize":.03,"ignore1":.22,"ignore2":.25,"conditional":.10,"parity":.05},
}
ps=[]
for name,gw in shifts.items():
    pp=mkprior(gw)
    for b in [1,2,3]:
        a,f,*_=eval_schedule(IG,budget=b,pdist=pp)
        ps.append({"shift":name,"budget":b,"accuracy":a,"fpr":f})
pd.DataFrame(ps).to_csv(OUT/"prior_shift.csv",index=False)

# ============================================================
# K. Generic selector transfer to reward-hack repairs
# ============================================================
hh=["faithful","magic","stale","premature","magic_stale","stale_premature","magic_premature","all3"]
rep=[("magic",(1,0,0),1.),("stale",(0,1,0),1.),("premature",(0,0,1),1.),
     ("magic_stale",(1,1,0),1.7),("stale_premature",(0,1,1),1.7),
     ("magic_premature",(1,0,1),1.7),("all",(1,1,1),2.5)]
def mask(name):
    if name=="faithful":return (0,0,0)
    if name=="all3":return (1,1,1)
    return (int("magic" in name),int("stale" in name),int("premature" in name))
HR=np.ones((len(hh),len(rep)),int)
for i,name in enumerate(hh):
    m=mask(name)
    if i==0:continue
    for k,(_,r,c) in enumerate(rep):
        HR[i,k]=int(not any(a and b for a,b in zip(m,r)))
def generic_schedule():
    active=np.ones(len(hh),bool);avail=list(range(len(rep)));out=[]
    for _ in range(5):
        ids=np.where(active)[0];vals=[]
        for k in avail:
            q=HR[ids,k].mean();vals.append(Hb(q))
        k=avail[int(np.argmax(vals))];out.append(k);active&=(HR[:,k]==1);avail.remove(k)
    return out
GS=generic_schedule();hp=np.array([.35,.12,.12,.12,.08,.08,.08,.05]);hp/=hp.sum()
tr=[]
unit=[0,1,2];rr=random.Random(MASTER+1000);randunit=[rr.sample(unit,3) for _ in range(5000)]
def eval_hr(s,b):
    sv=np.ones(len(hh),bool)
    for k in s[:b]:sv&=(HR[:,k]==1)
    y=np.zeros(len(hh),int);y[0]=1;pr=sv.astype(int)
    return float(hp[pr==y].sum()),float(hp[(y==0)&(pr==1)].sum()/hp[y==0].sum())
for b in [1,2,3]:
    a,f=eval_hr(GS,b);tr.append({"strategy":"generic_ig","budget":b,"accuracy":a,"fpr":f})
    ar=np.array([eval_hr(q,b) for q in randunit])
    tr.append({"strategy":"random_cost_matched","budget":b,"accuracy":ar[:,0].mean(),"fpr":ar[:,1].mean()})
pd.DataFrame(tr).to_csv(OUT/"rewardhack_selector_transfer.csv",index=False)

# ============================================================
# L. Verifier-adversary co-evolution
# ============================================================
shortcut=np.arange(1,len(hyps));sw=prior[1:]/prior[1:].sum()
coe=[]
for strategy in ["adaptive","random"]:
    reps=1 if strategy=="adaptive" else 100
    for seed in range(reps):
        rr=random.Random(MASTER+1100+seed);w=sw.copy();selected=[]
        for rd in range(10):
            if strategy=="adaptive":
                gains=[float((w*(1-RESP[1:,k])).sum()) for k in range(len(pool))]
                k=int(np.argmax(gains))
            else:k=rr.randrange(len(pool))
            selected.append(k)
            sv=np.ones(len(shortcut),float)
            for q in selected:sv*=RESP[1:,q]
            escape=float((w*sv).sum())
            fit=np.exp(1.2*sv);w=w*fit;w=.92*w/w.sum()+.08*np.ones_like(w)/len(w)
            coe.append({"strategy":strategy,"seed":seed,"round":rd+1,"escape_rate":escape})
pd.DataFrame(coe).to_csv(OUT/"coevolution_raw.csv",index=False)

# ============================================================
# Summary + figures
# ============================================================
summary={}
p=policy[(policy.domain=="policy")&(policy.strategy=="joint")]
summary["policy_joint_accuracy"]=float(p.accuracy.mean())
summary["policy_joint_fpr"]=float(p.fpr.mean())
a=pd.DataFrame(adv)
summary["adaptive_ig_budget1_fpr"]=float(a[(a.strategy=="ig")&(a.budget==1)].fpr.iloc[0])
summary["adaptive_ig_budget2_fpr"]=float(a[(a.strategy=="ig")&(a.budget==2)].fpr.iloc[0])
r=pd.DataFrame(rl)
summary["reinforce_outcome_final"]=float(r[(r.method=="outcome")&(r.step==800)].faithful.mean())
summary["reinforce_iav_final"]=float(r[(r.method=="iav_joint")&(r.step==800)].faithful.mean())
(OUT/"summary.json").write_text(json.dumps(summary,indent=2))

plt.figure(figsize=(7,4.5))
for m,g in a.groupby("strategy"):
    plt.plot(g.budget,g.fpr,marker="o",label=m)
plt.xlabel("Intervention budget");plt.ylabel("False-positive rate");plt.title("Unknown-shortcut verification")
plt.legend();plt.tight_layout();plt.savefig(OUT/"adaptive_budget.png",dpi=160);plt.close()

rg=r.groupby(["method","step"]).faithful.mean().reset_index()
plt.figure(figsize=(7,4.5))
for m,g in rg.groupby("method"):
    plt.plot(g.step,g.faithful,marker="o",label=m)
plt.xlabel("REINFORCE update");plt.ylabel("Faithful-policy probability");plt.title("Downstream RL incentive")
plt.legend();plt.tight_layout();plt.savefig(OUT/"reinforce.png",dpi=160);plt.close()

print(json.dumps(summary,indent=2))
print(f"Wrote results to {OUT}")
